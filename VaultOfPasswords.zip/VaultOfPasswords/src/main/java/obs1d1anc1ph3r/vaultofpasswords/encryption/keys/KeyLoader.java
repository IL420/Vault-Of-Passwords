package obs1d1anc1ph3r.vaultofpasswords.encryption.keys;

public class KeyLoader {
	
}
