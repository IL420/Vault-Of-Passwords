package obs1d1anc1ph3r.vaultofpasswords;

import obs1d1anc1ph3r.vaultofpasswords.userinterface.StartUpInterface;

public class VaultOfPasswords {

	public static void main(String[] args) throws InterruptedException, Exception {
		StartUpInterface startInterface = new StartUpInterface();
	}
}
